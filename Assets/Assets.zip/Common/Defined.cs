﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public static class Defined
{
    [Serializable]
    public class ColorInfo
    {
        public byte a;
        public byte r;
        public byte g;
        public byte b;

        public ColorInfo(byte a, byte r, byte g, byte b)
        {
            this.a = a;
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }
    //-------------------------------------------------------------------------        
    [Serializable]
    public class DrawInfo
    {
        public int id;
        public string name;
        public int pen;        
        public ColorInfo color;
        public int opt;

        public DrawInfo(int id, string sname, int penSize, ColorInfo penColor, int opt = 0)
        {
            this.id = id;
            this.name = sname;
            this.pen = penSize;
            this.color = penColor;
            this.opt = opt;
        }
    }
    //-------------------------------------------------------------------------
}
