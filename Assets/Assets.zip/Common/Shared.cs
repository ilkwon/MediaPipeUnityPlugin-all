﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


//-----------------------------------------------------------------------------
static public class Shared
{
    // public static string serverIP = "192.168.100.3";
    // public static int serverPort = 7099;

    public static int MaxWidth { get; private set; }
    public static int MaxHeight { get; private set; }
    public static int headerToggleIndex = 0;
    //-------------------------------------------------------------------------    
    //public static Sprite loading = Resources.Load("phase1/ImgLoading", typeof(Sprite)) as Sprite;
//    public static GameObject canvasWorld = Resources.Load("World/WorldRoomList/Home_World_Menu_T", typeof(GameObject)) as GameObject;
//    public static GameObject pageWorld = Resources.Load("World/WorldRoomList/RoomList", typeof(GameObject)) as GameObject;
//    public static GameObject itemRoom = Resources.Load("World/WorldRoomList/ContentsRoomItem", typeof(GameObject)) as GameObject;
//    public static GameObject btnMakeRoom = Resources.Load("World/WorldRoomList/CreateRoomItem", typeof(GameObject)) as GameObject;
//    public static GameObject indicator = Resources.Load("World/WorldRoomList/PageIndi", typeof(GameObject)) as GameObject;
//    public static GameObject worldCategorybtn = Resources.Load("World/WorldRoomList/CategoryBtnGroup", typeof(GameObject)) as GameObject;
//    
//    public static VideoPlayer screenMovie = Resources.Load("World/ScreenMovie", typeof(VideoPlayer)) as VideoPlayer;
    //-------------------------------------------------------------------------
    static Shared()
    {
#if !UNITY_EDITOR
        
#endif
    }
    //-------------------------------------------------------------------------
    public static void ApplicationQuitOrEditorStop()
    {
#if UNITY_EDITOR        
        UnityEditor.EditorApplication.isPlaying = false;
#else
        //Application.Quit();
        Shared.ApplicationQuitForAndroid();
#endif
    }
    //-------------------------------------------------------------------------
    public static void ApplicationQuitForAndroid()
    {

    }
    //-------------------------------------------------------------------------
    public static void SetResolutionMax()
    {
        int ratioWidth = 16;
        int ratioHeight = 9;
        MaxWidth = Screen.width;
        MaxHeight = Screen.width * ratioHeight / ratioWidth;
        Screen.SetResolution(MaxWidth, MaxHeight, true);
    }
    //-------------------------------------------------------------------------
    public static string GetCurrentDirectory()
    {
        string pathname = Application.dataPath;//.Replace("Assets/", "");        
        pathname += "/../";
        return pathname;
    }
    //-------------------------------------------------------------------------
    public static bool GetActive(GameObject go)
    {
        return go.activeSelf;
    }
    //-------------------------------------------------------------------------    
    public static void SetActive(GameObject go, bool active)
    {
        if (GetActive(go) != active)
            go.SetActive(active);
    }
    //-------------------------------------------------------------------------
    static public GameObject AddChild(Transform parent, GameObject go, bool scaleNomalize = true)
    {
        GameObject obj = GameObject.Instantiate(go, parent) as GameObject;

        obj.transform.localPosition = Vector3.zero;
        obj.transform.localRotation = Quaternion.identity;
        if (scaleNomalize)
            obj.transform.localScale = Vector3.one;
        return obj;
    }
    //-------------------------------------------------------------------------
    static public T AddChild<T>(this Transform parent, GameObject go) where T : Component
    {
        T comp = AddChild(parent, go).GetComponent<T>();
        if (comp != null) return comp;

        return AddChild(parent, go).AddComponent<T>();
    }
    //------------------------------------------------------------------------
    static public int GetActiveChildrenCount(Transform parent)
    {
        int count = 0;
        for (int i = parent.childCount - 1; i >= 0; --i)
        {
            Transform child = parent.GetChild(i);
            if (GetActive(child.gameObject))
                count++;
        }
        return count;
    }
    //------------------------------------------------------------------------
    static public void SetActiveChildren(Transform parent, bool active)
    {
        for (int i = parent.childCount - 1; i >= 0; --i)
        {
            SetActive(parent.GetChild(i).gameObject, active);
        }
    }
    //------------------------------------------------------------------------
    static public void DestroyChildren(Transform parent)
    {
        for (int i = parent.childCount - 1; i >= 0; --i)
        {
            GameObject.Destroy(parent.GetChild(i).gameObject);
        }
    }
    //-------------------------------------------------------------------------
    public static byte[] Encompress(byte[] buffer)
    {
        MemoryStream ostream = new MemoryStream();
        using (DeflateStream dstream = new DeflateStream(ostream, CompressionMode.Compress))
        {
            dstream.Write(buffer, 0, buffer.Length);
        }
        return ostream.ToArray();
    }
    //-------------------------------------------------------------------------
    public static byte[] Decompress(byte[] buffer)
    {
        MemoryStream istream = new MemoryStream(buffer);
        byte[] newbuffer = null;
        DeflateStream dstream = new DeflateStream(istream, CompressionMode.Decompress);

        int totalReadByte = 0;
        int readByte = -1;
        newbuffer = new byte[4096];
        while (readByte != 0)
        {
            readByte = dstream.Read(newbuffer, 0, newbuffer.Length);

            totalReadByte += readByte;
        }

        System.Array.Resize(ref newbuffer, totalReadByte);
        dstream.Close();

        return newbuffer;
    }
    //-------------------------------------------------------------------------
    public static void DebugLog(string message, string colorName)
    {
        string log = string.Format("<color={0}>{1}</color>", colorName, message);
        Debug.Log(log);
    }
    //--------------------------------------------------------------------------
    public static byte[] Serialize(object obj)
    {
        try
        {
            using (MemoryStream stream = new MemoryStream()) {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(stream, obj);

                return stream.ToArray();
            }
        }
        catch (Exception ex)
        {
            Debug.Log(ex.ToString());
        }

        return null;
    }
    //--------------------------------------------------------------------------
    public static object Deserialize(byte[] bytes)
    {
        try
        {
            using (MemoryStream stream = new MemoryStream(bytes))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                stream.Position = 0;

                return binaryFormatter.Deserialize(stream);
            }
        }
        catch (Exception ex)
        {
            Debug.Log(ex.ToString());
        }

        return null;
    }
    //--------------------------------------------------------------------------
    public static byte[] GetBytes(object obj)
    {
        int size = Marshal.SizeOf(obj);
        byte[] arr = new byte[size];
        //IntPtr ptr = Marshal.AllocHGlobal(size);
        IntPtr ptr = Marshal.UnsafeAddrOfPinnedArrayElement(arr, 0);
        Marshal.StructureToPtr(obj, ptr, false);
        //Marshal.StructureToPtr(obj, ptr, true);
        Marshal.Copy(ptr, arr, 0, size);
        Marshal.FreeHGlobal(ptr);

        return arr;
    }
    //-------------------------------------------------------------------------
    public static T FromBytes<T>(byte[] arr)
    {
        T str = default;

        int size = Marshal.SizeOf(str);
        IntPtr ptr = Marshal.AllocHGlobal(size);

        Marshal.Copy(arr, 0, ptr, size);

        str = (T)Marshal.PtrToStructure(ptr, str.GetType());
        Marshal.FreeHGlobal(ptr);

        return str;
    }
    //-------------------------------------------------------------------------
    public static ArrayList DevideArray(byte[] bigBytes, int range)
    {
        range *= 1000;
        int pos = 0;
        
        /// List<byte[]> == ArrayList 
        ArrayList bytesList = new ArrayList();
        int remaining;
        while ((remaining = bigBytes.Length - pos) > 0)
        {
            byte[] block = new byte[Mathf.Min(remaining, range)];

            Array.Copy(bigBytes, pos, block, 0, block.Length);
            bytesList.Add(block);
            pos += block.Length;
        }
        return bytesList;
    }

    //-------------------------------------------------------------------------
    public static T[] CopySlice<T>(this T[] source, int index, int length, bool padToLength = false)
    {
        int n = length;
        T[] slice = null;

        if (source.Length < index + length)
        {
            n = source.Length - index;
            if (padToLength)
                slice = new T[length];
        }
        if (slice == null) 
            slice = new T[n];
        Array.Copy(source, index, slice, 0, n);

        return slice;
    }

    //-------------------------------------------------------------------------
    // you have to restore using linq SelectMany() method.
    // byte[] bytes = buffer.SelectMany(a => a).ToArray();    
    public static IEnumerable<T[]> Slices<T>(this T[] source, int count, bool padToLength = false)
    {
        for (var i = 0; i < source.Length; i += count)
            yield return source.CopySlice(i, count, padToLength);
    }
    //-------------------------------------------------------------------------
    static public void ListShuffle<T>(List<T> list)
    {        
        UnityEngine.Random.InitState((int)System.DateTime.Now.Ticks);
        int size = list.Count;
        for (int i = 0; i < size; i++)
        {
            T item = list[i];
            int random = UnityEngine.Random.Range(i, size);

            // swap...                
            list[i] = list[random];
            list[random] = item;
        }
    }
    //-------------------------------------------------------------------------
    static public void ArrayShuffle<T>(T[] array)
    {
        UnityEngine.Random.InitState((int)System.DateTime.Now.Ticks);
        int size = array.Length;
        for (int i = 0; i < size; i++)
        {
            T item = array[i];
            int random = UnityEngine.Random.Range(i, size);

            // swap...                
            array[i] = array[random];
            array[random] = item;
        }
    }
    //-------------------------------------------------------------------------
    /// <summary>
    /// Finds the MAC address of the first operation NIC found.
    /// </summary>
    /// <returns>The MAC address.</returns>
    public static string GetMacAddress()
    {
        string macAddresses = string.Empty;

        foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if (nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
            {
                macAddresses += nic.GetPhysicalAddress().ToString();
                break;
            }
        }

        return macAddresses;
    }
 
    //-------------------------------------------------------------------------
    private static string androidEnv = "android.os.Environment";
    private static string androidNetConnectivity = "android.net.ConnectivityManager";
    private static string androidNetTelephonyManager = "android.telephony.TelephonyManager";

    private const long kbyte = 1024;
    private const long mbyte = kbyte * 1024;
    private const long gbyte = mbyte * 1024;
    private const long tbyte = gbyte * 1024;

    //-------------------------------------------------------------------------
    public static string ToPrettySize(this int value, int decimalPlaces = 0)
    {
        return ((long)value).ToSize(decimalPlaces);
    }
    //-------------------------------------------------------------------------
    public static string ToSize(this long value, int decimalPlaces = 0)
    {
        var tb = Math.Round((double)value / tbyte, decimalPlaces);
        var gb = Math.Round((double)value / gbyte, decimalPlaces);
        var mb = Math.Round((double)value / mbyte, decimalPlaces);
        var kb = Math.Round((double)value / kbyte, decimalPlaces);
        
        string chosenValue = tb > 1 ? string.Format("{0}TB", tb)
                           : gb > 1 ? string.Format("{0}GB", gb)
                           : mb > 1 ? string.Format("{0}MB", mb)
                           : kb > 1 ? string.Format("{0}KB", kb)
                           : string.Format("{0}B", Math.Round((double)value, decimalPlaces));

        return chosenValue;
    }
    //-------------------------------------------------------------------------
    public static string ToGigabyteSize(this long value, int decimalPlaces = 1)
    {
        var asGb = Math.Round((double)value / gbyte, decimalPlaces);

        if (asGb == 0)
        {
            asGb = 0.1; // 용량이 0일경우 0.1로 강제 처리
        }

        return string.Format("{0}GB", asGb);
    }
    //-------------------------------------------------------------------------
    public static string GetAndroidExternalFilesSize()
    {
#if UNITY_EDITOR
        return ToGigabyteSize(100);
#else
        AndroidJavaObject statFs = new AndroidJavaObject("android.os.StatFs", Application.persistentDataPath);
        long size =  (long)statFs.Call<int>("getBlockSize") * (long)statFs.Call<int>("getAvailableBlocks");
        return ToGigabyteSize(size);
#endif
    }
    //-------------------------------------------------------------------------

    // 104857600(100MB), 524288000(500MB)
    private const long StopWritingBlockSize = 524288000;

    public static bool IsPossibleToWrite()
    {
#if UNITY_EDITOR
        return true;
#else
        AndroidJavaObject statFs = new AndroidJavaObject("android.os.StatFs", Application.persistentDataPath);
        long size = (long)statFs.Call<int>("getBlockSize") * (long)statFs.Call<int>("getAvailableBlocks");

        if (size <= StopWritingBlockSize)
        {
            Debug.Log("Can not wirte to storage");
            return false;
        }
        return true;
#endif
    }

    ///
    /// 클라이언트 IP 주소 얻어오기...
    ///
    public static string GetClientIP()
    {
        System.Net.IPHostEntry host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
        string ip = string.Empty;
        for (int i = 0; i < host.AddressList.Length; i++)
        {
            if (host.AddressList[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                ip = host.AddressList[i].ToString();
            }

        }
        return ip;
    }
  
    //-------------------------------------------------------------------------
    private static void DebugView(string log)
    {
        
    }

    public static void LoadDeviceByName()
    {
        if(UnityEngine.XR.XRSettings.loadedDeviceName.ToLower().Equals("cardboard") == false)
        {
            //string deviceName = vrEnabled ? "Cardboard" : "";
            UnityEngine.XR.XRSettings.LoadDeviceByName("Cardboard");
        }
    }
    //-------------------------------------------------------------------------
    public static T GetOrAddComponent<T>(this GameObject gameObject) where T : Component
    {
        return gameObject.GetComponent<T>() ?? gameObject.AddComponent<T>();
    }
    //-------------------------------------------------------------------------
}
