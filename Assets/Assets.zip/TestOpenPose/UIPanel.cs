using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class UIPanel : MonoBehaviour
{

    public TMP_Text frame;
    public TMP_Text message;
}
