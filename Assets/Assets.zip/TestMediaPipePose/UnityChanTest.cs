
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
//using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.XR;
using static TMPro.SpriteAssetUtilities.TexturePacker_JsonArray;
using Mediapipe.Unity;

public class UnityChanTest : Singleton<UnityChanTest>
{
    [SerializeField] PoseWorldLandmarkListAnnotationController _landmarkController;
    [SerializeField] private UIRoot ui;
    int boneNum = 33;
    private Transform[] boneT;
    private float playTime;
    private Quaternion[] initRot;
    private Quaternion[] initInv;
    private Animator anim;
    private List<Vector3[]> pos = new();
    public int startFrame = 0;
    public String endFrame;
    private int sFrame = 0;
    private int eFrame;

    private int frame;
    //-------------------------------------------------------------------------
    private void Start()
    {
        playTime = 0f;
        anim = GetComponent<Animator>();
        pos = GetPosData();
        GetInitInfo02();
        if (pos != null)
        {
            // inspector���� ������ ���� frame. ���� frame, ��ȣ ����.
            if (startFrame >= 0 && startFrame < pos.Count)
            {
                sFrame = startFrame;
            }
            else
            {
                sFrame = 0;
            }
            int ef;
            if (int.TryParse(endFrame, out ef))
            {
                if (ef >= sFrame && ef < pos.Count)
                {
                    eFrame = ef;
                }
                else
                {
                    eFrame = pos.Count - 1;
                }
            }
            else
            {
                eFrame = pos.Count - 1;
            }
            frame = sFrame;
        }

    }
    public float value = 100;
    private List<string> lines;
    private List<Vector3[]> GetPosData()
    {
        string file = Application.dataPath + "/AnimationFile23.txt";

        lines = System.IO.File.ReadLines(file).ToList();
        List<Vector3[]> ret = new List<Vector3[]>();
        foreach (string line in lines)
        {
            string[] points = line.Split(',');
            int boneNum = 33;
            Vector3[] joints = new Vector3[boneNum];
            for (int i = 0; i < points.Length-1; i += 3)
            {
                int n = (i / 3);
                float x = -float.Parse(points[i+0]) / value;
                float y = float.Parse(points[i+1]) / value;
                float z = -float.Parse(points[i+2]) / (value * 3);
                joints[n] = new Vector3(x, y, z);
            }
            ret.Add(joints);
        }
        return ret;
    }

    //-------------------------------------------------------------------------
    int[] bones       = new int[9] {0, 24, 26, 23, 25, 12, 14, 11, 13 }; 
    int[] childBones = new int[9] {0, 26, 28, 25, 27, 14, 16, 13, 15 };
    Vector3 rootPosition;
    Quaternion rootRotation;
    private Transform bone0Hip;
    private void GetInitInfo02() 
    {
        boneT = new Transform[boneNum];
        initRot = new Quaternion[boneNum];
        initInv = new Quaternion[boneNum];

         bone0Hip = anim.GetBoneTransform(HumanBodyBones.Hips);
        boneT[0] = anim.GetBoneTransform(HumanBodyBones.Spine);

        boneT[11] = anim.GetBoneTransform(HumanBodyBones.LeftUpperArm);  // shoulder
        boneT[12] = anim.GetBoneTransform(HumanBodyBones.RightUpperArm);
        
        boneT[13] = anim.GetBoneTransform(HumanBodyBones.LeftLowerArm);  // elbow      
        boneT[14] = anim.GetBoneTransform(HumanBodyBones.RightLowerArm); 

        boneT[15] = anim.GetBoneTransform(HumanBodyBones.LeftHand);     // wrist
        boneT[16] = anim.GetBoneTransform(HumanBodyBones.RightHand);

        boneT[23] = anim.GetBoneTransform(HumanBodyBones.LeftUpperLeg);     // hip
        boneT[24] = anim.GetBoneTransform(HumanBodyBones.RightUpperLeg);    
        
        boneT[25] = anim.GetBoneTransform(HumanBodyBones.LeftLowerLeg);     // knee
        boneT[26] = anim.GetBoneTransform(HumanBodyBones.RightLowerLeg);

        boneT[27] = anim.GetBoneTransform(HumanBodyBones.LeftFoot);         // foot
        boneT[28] = anim.GetBoneTransform(HumanBodyBones.RightFoot);        


        if (boneT[0] == null)
        {
            ErrorMessage("<color=blue>Error! Failed to get Bone Transform. " +
                "Confirm wherther animation type of your model is Humanoid</color>");

            return;
        }

        var spine = anim.GetBoneTransform(HumanBodyBones.Spine);
        // Spine, LHip, RHip�� �̿��� �ﰢ���� ����� �װ��� ���� �������� �����Ѵ�.
        Vector3 initForward = TriangleNormal(boneT[0].position, boneT[23].position, boneT[24].position);
        initInv[0] = Quaternion.Inverse(Quaternion.LookRotation(initForward));

        // initPosition = boneT[0].position;
        rootPosition = this.transform.position;
        rootRotation = this.transform.rotation;
        initRot[0] = bone0Hip.rotation;
        hipHeight = bone0Hip.position.y - this.transform.position.y;
        for (int i = 0; i < bones.Length; i++)
        {
            int b = bones[i];
            int cb = childBones[i];

            // ��� ���� ȸ�� �ʱⰪ
            initRot[b] = boneT[b].rotation;
            // �ʱ� ���� ���⿡�� ���� ���ʹϾ�
            initInv[b] = Quaternion.Inverse(
                Quaternion.LookRotation(boneT[b].position - boneT[cb].position, initForward));
        }
    }
    public bool showDebugCube = false;

    public float upPosition = 0.1f; // �� ��ġ ������(����: m). ������� �����ϸ� ĳ���� ��ü�� ���� �̵�
    public int nowFrame_readonly; // ���� ������ (�б� ����)
    private float scaleRatio = 0.001f;  // pos.txt�� Unity ���� ������ ����
                                        // pos.txt�� ������ mm�̰� Unity�� m�̹Ƿ�, 0.001�� ����� ���� ����. ���� ũ�⿡ ���� ����
    private float hipHeight = 0f;
    public void Update()
    {

        if (pos == null || boneT[24] == null)
        {
            return;
        }
        playTime += Time.deltaTime;
        frame = sFrame + (int)(playTime * 30.0f);  // pos.txt�� 30fps�� ����           

        if (frame > eFrame)
        {
            frame = 0;
            playTime = 0f;
            return;
        }

        nowFrame_readonly = frame; // Inspector ǥ�ÿ�

        //if (showDebugCube)
        {
            UpdateCube(frame); // ����׿� Cube�� ǥ���Ѵ�
        }

        Vector3[] nowPos = pos[frame];
        ErrorMessage("nowPos[0]:" + nowPos[0]);
        // ������ �̵��� ȸ��        
        Vector3 posForward = TriangleNormal(nowPos[0], nowPos[23], nowPos[24]);

        this.transform.position = rootRotation * nowPos[0] * 0.1f + rootPosition + new Vector3(0, upPosition - hipHeight, 0);
       bone0Hip.rotation = rootRotation * Quaternion.LookRotation(posForward) * initInv[0] * initRot[0];

        // �� ���� ȸ��.
        for (int i=0; i<bones.Length; i++)
        {
            int b = bones[i];
            int cb = childBones[i];
            boneT[b].rotation = rootRotation * Quaternion.LookRotation(nowPos[b] - nowPos[cb], posForward) * initInv[b] * initRot[b];
        }
    }

    //-------------------------------------------------------------------------
    private Transform[] cubeT;
    float cubeScale = 0.1f;
    private void UpdateCube(int frame)
    {
        float scaleRatio = .5f;
        if (cubeT == null)
        {
            // �ʱ�ȭ �ϰ���cube�� �����Ѵ�
            cubeT = new Transform[boneNum];

            for (var i = 0; i < boneNum; i++)
            {
                var t = GameObject.CreatePrimitive(PrimitiveType.Cube).transform;
                t.transform.parent = GameObject.Find("CubeBody").transform;
                t.localPosition = pos[frame][i] * scaleRatio;
                t.name = i.ToString();
                t.localScale = new Vector3(cubeScale, cubeScale, cubeScale);
                cubeT[i] = t;

                Destroy(t.GetComponent<BoxCollider>());
            }
        }
        else
        {
            // �𵨰� ��ġ�� �ʵ��� ���� �̵��Ͽ� ǥ��
            Vector3 offset = new Vector3(1.2f, 0, 0);

            // �̹� �ʱ�ȭ�� ���, cube�� ��ġ�� ������Ʈ�Ѵ�
            for (int i = 0; i < boneNum; i++)
            {
                cubeT[i].localPosition = pos[frame][i] * scaleRatio + new Vector3(0, upPosition, 0) + offset;
            }
        }
    }


    //-------------------------------------------------------------------------
    // ������ 3���� ������ �̷���� �ﰢ���� �����̰� ���̰� 1�� ���͸� ��ȯ�Ѵ�    
    Vector3 TriangleNormal(Vector3 a, Vector3 b, Vector3 c)
    {
        Vector3 d1 = a - b;
        Vector3 d2 = a - c;

        Vector3 dd = Vector3.Cross(d1, d2);
        dd.Normalize();

        return dd;
    }
    //-------------------------------------------------------------------------
    private void ErrorMessage(string msg)
    {
        ui.message.text = msg;
        Debug.Log(msg);
    }
    //---------------------------------------------------------------------------
}
